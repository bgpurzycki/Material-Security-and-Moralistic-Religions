################################################################################
# Analysis of Belief in Moralizing Gods
################################################################################
 library(rethinking)
  setwd("your path here")

######################################################################### Part 1
# First, lets simulate some data to check our statistical model
############################################ Set seed for replication of results
set.seed(1)

###################### Make sites
Site <- rmultinom(300, prob=c(1,2,2,1,3,1,2,1),size=1) # Imbalanced site representation
Site <- which(Site==1,arr.ind=T)[,1]
hist(Site)

###################### Make wealth
Wealth <- rbinom(300, 0.3, size=1)                     # 0.3 are insecure
hist(Wealth)

###################### Make age
Age <- rpois(300,40)                                   # Adults
hist(Age)

###################### Make education
Education <- rpois(300, 5)                             # Basic education dist
hist(Education)

###################### Make male
Male <- rbinom(300, 0.5, size=1)                       # 0.5 are women
hist(Male)

###################### Make kids
Kids <- rpois(300, 4)                                  # Basic rs dist
hist(Kids)

################################################### Now make simulated outcomes
A1<-rnorm(8, 0,0.1)  # Var over group
A2<-rnorm(8, 0,0.1)  #
A3<-rnorm(8, 0,0.1)  #
A4<-rnorm(8, 0,0.2)  #
A5<-rnorm(8, 0,0.3)  #
A6<-rnorm(8, 0,0.3)  #

X<-c() # Outcomes

#### Mu in model are the numeric effects below
Mu <- c(-0.3,0.24,0.2,0.05,-0.06,0.34)

for(i in 1:300){
X[i] <- rbeta(1,
logistic((Mu[1]+A1[Site[i]]) + (Mu[2]+A2[Site[i]])*log(Age[i]) + (Mu[3]+A3[Site[i]])*Male[i] + (Mu[4]+A4[Site[i]])*Kids[i]+ (Mu[5]+A5[Site[i]])*Education[i] + (Mu[6]+A6[Site[i]])*Wealth[i] )*12,
(1-logistic((Mu[1]+A1[Site[i]]) + (Mu[2]+A2[Site[i]])*log(Age[i]) + (Mu[3]+A3[Site[i]])*Male[i] + (Mu[4]+A4[Site[i]])*Kids[i] + (Mu[5]+A5[Site[i]])*Education[i] + (Mu[6]+A6[Site[i]])*Wealth[i] ))*12 )
 }

MBG<-X
 
##################################################### Function to Transform Data
ScaleBeta <- function(X){
a<-min(X)
b<-max(X)
y<-X
Samp<-50

y2 <- (y-a)/(b-a)

y3<-(y2*(Samp - 1) + 0.5)/Samp

y3
}

ScaleBeta(MBG)
dens(MBG)


#################################################### Extra data bits for indices
N <- 300            # Cases
P <- 6              # Params
L <- 8              # Sites

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  MBG=MBG,
  Age=Age,    
  Wealth=Wealth,
  Kids=Kids,
  Education=Education,
  Male=Male,
  Site=Site   
)

#################################################################### Stan Models
model_code_M1="
data{
  int N;
  int P;
  int L;
  
  vector<lower=0,upper=1>[N] MBG;
  int Site[N];
  
  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;
  
  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
} 

model{
vector[N] A;
vector[N] B;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);
  
 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1); 
             }
             
#### M1 - Wealth Insecurity and Education and Kids
  for(i in 1:N){
    B[i] = (1-inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Kids[i] + Beta[Site[i],5]*Education[i] + Beta[Site[i],6]*Wealth[i]))*InvScale;
    A[i] = inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Kids[i] + Beta[Site[i],5]*Education[i] + Beta[Site[i],6]*Wealth[i])*InvScale;
     }

  MBG ~ beta(A,B);         
}
"

model_code_M2="
data{
  int N;
  int P;
  int L;

  vector<lower=0,upper=1>[N] MBG;
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;
vector[N] B;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M2 - Wealth Insecurity and Kids
  for(i in 1:N){
    B[i] = (1-inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Kids[i] + Beta[Site[i],6]*Wealth[i]))*InvScale;
    A[i] = inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Kids[i] + Beta[Site[i],6]*Wealth[i])*InvScale;
     }

  MBG ~ beta(A,B);
}
"

model_code_M3="
data{
  int N;
  int P;
  int L;

  vector<lower=0,upper=1>[N] MBG;
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;
vector[N] B;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M3 -  Wealth Insecurity and Education
  for(i in 1:N){
    B[i] = (1-inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],5]*Education[i] + Beta[Site[i],6]*Wealth[i]))*InvScale;
    A[i] = inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],5]*Education[i] + Beta[Site[i],6]*Wealth[i])*InvScale;
     }

  MBG ~ beta(A,B);

}
"

model_code_M4="
data{
  int N;
  int P;
  int L;

  vector<lower=0,upper=1>[N] MBG;
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
  vector[N] Moral;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;
vector[N] B;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M3 -  Wealth Insecurity and MBG
  for(i in 1:N){
    B[i] = (1-inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],6]*Wealth[i] + Beta[Site[i],7]*Moral[i]))*InvScale;
    A[i] = inv_logit(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],6]*Wealth[i] + Beta[Site[i],7]*Moral[i])*InvScale;
     }

  MBG ~ beta(A,B);

}
"

####################################################################### Check M1
fit <- stan(model_code=model_code_M1, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1,refresh=1,seed=12435)

############################################################# Check fit and MCMC
print(fit,pars=c("Mu","Sigma"))

Mu_pred <- get_posterior_mean(fit,"Mu")
plot(Mu, Mu_pred[,dim(Mu_pred)[2]])

Beta_pred <- get_posterior_mean(fit,"Beta")
Beta <- c(Mu+c(A1[1]+A2[1]+A3[1]+A4[1]+A5[1]+A6[1]),Mu+c(A1[2]+A2[2]+A3[2]+A4[2]+A5[2]+A6[2]),Mu+c(A1[3]+A2[3]+A3[3]+A4[3]+A5[3]+A6[3]),Mu+c(A1[4]+A2[4]+A3[4]+A4[4]+A5[4]+A6[4]),
          Mu+c(A1[5]+A2[5]+A3[5]+A4[5]+A5[5]+A6[5]),Mu+c(A1[6]+A2[6]+A3[6]+A4[6]+A5[6]+A6[6]),Mu+c(A1[7]+A2[7]+A3[7]+A4[7]+A5[7]+A6[7]),Mu+c(A1[8]+A2[8]+A3[8]+A4[8]+A5[8]+A6[8]))

windows()
plot(Beta, Beta_pred[,dim(Beta_pred)[2]])
cor(Beta, Beta_pred[,dim(Beta_pred)[2]])

windows()
traceplot(fit,pars=c("Mu","Sigma"))


######################################################################### Part 2
################################################## Analysis of real data
d<-read.csv("OutcomeData.csv")
library(LaplacesDemon)

d2<-data.frame(d$SITE,d$CHILDREN,d$AGE,d$SEX,d$FORMALED,d$SEC1,d$MBG)   # Get variables
d3<-d2[complete.cases(d2),]      # Drop missings

Site <- as.numeric(d3$d.SITE)
Kids <- d3$d.CHILDREN
Age <- ifelse( (d3$d.AGE - 15) >=45,45,d3$d.AGE - 15)   # Turn age into years of exposure to reproduction... ie cut off pre- and post- reproductive windows
Male <- d3$d.SEX
Education <- d3$d.FORMALED 
Wealth <- d3$d.SEC1         # Food SECURITY
MBG <- ScaleBeta(d3$d.MBG)  # Slightly scale off of boundaries

N <- length(MBG)     # Cases
P <- 6              # Params
L <- 8              # Sites

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  MBG=MBG,
  Kids=Kids,
  Age=Age,    
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site   
)


############################################################################# M1
fit_M1 <- stan(model_code=model_code_M1, data = model_dat, thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M1
print(fit_M1,pars="Mu")
print(fit_M1,pars="Beta")

windows()
traceplot(fit_M1,pars="Mu")
windows()
traceplot(fit_M1,pars="Beta")

BETA<-extract(fit_M1,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,2:6]
colnames(XX)<-c("Age","Male","Kids","Education","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################################# M2
fit_M2 <- stan(model_code=model_code_M2, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M2
print(fit_M2,pars="Mu")
print(fit_M2,pars="Beta")

windows()
traceplot(fit_M2,pars="Mu")
windows()
traceplot(fit_M2,pars="Beta")

BETA<-extract(fit_M2,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,4,6)]
colnames(XX)<-c("Age","Male","Kids","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################################# M3
fit_M3 <- stan(model_code=model_code_M3, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M3
print(fit_M3,pars="Mu")
print(fit_M3,pars="Beta")

windows()
traceplot(fit_M3,pars="Mu")
windows()
traceplot(fit_M3,pars="Beta")

BETA<-extract(fit_M3,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,5,6)]
colnames(XX)<-c("Age","Male","Education","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################# Make Results Table
 library(rethinking)
 library(xtable)

colPCIl <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[1]
                               }
                               K
                               }
colPCIh <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[2]
                               }
                               K
                               }

  Mu_M1<-extract(fit_M1,pars=c("Mu"))$Mu
  Mu_M2<-extract(fit_M2,pars=c("Mu"))$Mu
  Mu_M3<-extract(fit_M3,pars=c("Mu"))$Mu

  Res<-ResM<-ResL<-ResH<-matrix(NA,nrow=6,ncol=3)

  ResM[,1] <- round(colMeans(Mu_M1),2)
  ResM[,2] <- round(colMeans(Mu_M2),2)
  ResM[,3] <- round(colMeans(Mu_M3),2)

  ResL[,1] <- round(colPCIl(Mu_M1),2)
  ResL[,2] <- round(colPCIl(Mu_M2),2)
  ResL[,3] <- round(colPCIl(Mu_M3),2)

  ResH[,1] <- round(colPCIh(Mu_M1),2)
  ResH[,2] <- round(colPCIh(Mu_M2),2)
  ResH[,3] <- round(colPCIh(Mu_M3),2)


   ResL[5,2]<-ResL[4,3]<-ResH[5,2]<-ResH[4,3]<-ResM[5,2]<-ResM[4,3]<-NA

  for(i in 1:6){
  for(j in 1:3){
  Res[i,j] <- paste0(ResM[i,j]," (",ResL[i,j],", ",ResH[i,j],")")
             }}

  Res[5,2]<-Res[4,3]<-NA


  colnames(Res) <- c("M1","M2","M3")
  rownames(Res) <- c("Intercept","Age","Male","Kids","Education","Food Security")

  xtable(Res)

 ResBig<-Res


##################################################################### Local Gods
d2<-data.frame(d$SITE,d$CHILDREN,d$AGE,d$SEX,d$FORMALED,d$SEC1,d$MLG,d$MBG)  # Get variables
d3<-d2[complete.cases(d2),]      # Drop missings

Site <- as.numeric(d3$d.SITE)
Kids <- d3$d.CHILDREN
Age <- ifelse( (d3$d.AGE - 15) >=45,45,d3$d.AGE - 15)  # Turn age into years of exposure to reproduction... ie cut off pre- and post- reproductive windows
Male <- d3$d.SEX
Education <- d3$d.FORMALED
Wealth <- d3$d.SEC1         # Wealth INSECURITY
MBG <- ScaleBeta(d3$d.MLG)        # Hacky coding, via purposful mislabling of MBG with MLG... Lets us use same M1-M3
Moral <- ScaleBeta(d3$d.MBG)

N <- length(MBG)     # Cases
P <- 6              # Params
L <- 8              # Sites

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  MBG=MBG,
  Kids=Kids,
  Age=Age,
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site
)


############################################################################# M1
fit_M1 <- stan(model_code=model_code_M1, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M1
print(fit_M1,pars="Mu")
print(fit_M1,pars="Beta")

windows()
traceplot(fit_M1,pars="Mu")
windows()
traceplot(fit_M1,pars="Beta")

BETA<-extract(fit_M1,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,2:6]
colnames(XX)<-c("Age","Male","Kids","Education","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################################# M2
fit_M2 <- stan(model_code=model_code_M2, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M2
print(fit_M2,pars="Mu")
print(fit_M2,pars="Beta")

windows()
traceplot(fit_M2,pars="Mu")
windows()
traceplot(fit_M2,pars="Beta")

BETA<-extract(fit_M2,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,4,6)]
colnames(XX)<-c("Age","Male","Kids","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################################# M3
fit_M3 <- stan(model_code=model_code_M3, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M3
print(fit_M3,pars="Mu")
print(fit_M3,pars="Beta")

windows()
traceplot(fit_M3,pars="Mu")
windows()
traceplot(fit_M3,pars="Beta")

BETA<-extract(fit_M3,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,5,6)]
colnames(XX)<-c("Age","Male","Education","Food Security")
windows()
caterpillar.plot(XX)
}


################################################################ Add MBG control
N <- length(MBG)     # Cases
P <- 7              # Params
L <- 8              # Sites

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  MBG=MBG,
  Kids=Kids,
  Age=Age,
  Moral=Moral,
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site
)


############################################################################# M1
fit_M4 <- stan(model_code=model_code_M4, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M4
print(fit_M4,pars="Mu")
print(fit_M4,pars="Beta")

windows()
traceplot(fit_M4,pars="Mu")
windows()
traceplot(fit_M4,pars="Beta")

BETA<-extract(fit_M4,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,6,7)]
colnames(XX)<-c("Age","Male","Food Security","MBG")
windows()
caterpillar.plot(XX)
}



############################################################# Make Results Table
 library(rethinking)
 library(xtable)

colPCIl <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[1]
                               }
                               K
                               }
colPCIh <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[2]
                               }
                               K
                               }

  Mu_M1<-extract(fit_M1,pars=c("Mu"))$Mu
  Mu_M2<-extract(fit_M2,pars=c("Mu"))$Mu
  Mu_M3<-extract(fit_M3,pars=c("Mu"))$Mu
  Mu_M4<-extract(fit_M4,pars=c("Mu"))$Mu

  Res<-ResM<-ResL<-ResH<-matrix(NA,nrow=7,ncol=4)

  ResM[,1] <- c(round(colMeans(Mu_M1),2),NA)
  ResM[,2] <- c(round(colMeans(Mu_M2),2),NA)
  ResM[,3] <- c(round(colMeans(Mu_M3),2),NA)
  ResM[,4] <- round(colMeans(Mu_M4),2)

  ResL[,1] <- c(round(colPCIl(Mu_M1),2),NA)
  ResL[,2] <- c(round(colPCIl(Mu_M2),2),NA)
  ResL[,3] <- c(round(colPCIl(Mu_M3),2),NA)
  ResL[,4] <- round(colPCIl(Mu_M4),2)

  ResH[,1] <- c(round(colPCIh(Mu_M1),2),NA)
  ResH[,2] <- c(round(colPCIh(Mu_M2),2),NA)
  ResH[,3] <- c(round(colPCIh(Mu_M3),2),NA)
  ResH[,4] <- round(colPCIh(Mu_M4),2)


  ResL[5,2]<-ResL[4,3]<-ResH[5,2]<-ResH[4,3]<-ResM[5,2]<-ResM[4,3]<-NA
  ResL[4,4] <- ResL[5,4]<- ResH[4,4] <- ResH[5,4]<- ResM[4,4] <- ResM[5,4]<- NA

  for(i in 1:7){
  for(j in 1:4){
  Res[i,j] <- paste0(ResM[i,j]," (",ResL[i,j],", ",ResH[i,j],")")
             }}

  Res[5,4]<-Res[4,4]<-Res[5,2]<-Res[4,3]<-NA


  colnames(Res) <- c("M1","M2","M3","M4")
  rownames(Res) <- c("Intercept.","Age.","Male.","Kids.","Education.","Food Security.","MBG.")

  xtable(Res)

 ResLocal<-Res


################################################################## Merge Results

 ResFinal <- cbind(c(rep("Moralistic Deity",6),rep("Local Deity",7) ) ,   rbind(cbind(ResBig,rep(NA,6)), ResLocal))
colnames(ResFinal)<-c("Outcome","M1","M2","M3","M4")
 xtable(ResFinal)



################################################################# Figure S1
 
 d <- read.csv("OutcomeData.csv")
 View(d)
 
 MAT <- tapply(d$SEC1, d$SITE, FUN = mean, na.rm = T)
 MOR <- tapply(d$MBG, d$SITE, mean, na.rm = T)
 MOR.L <- tapply(d$MLG, d$SITE, mean, na.rm = T)
 PUN.L <- tapply(d$LGDIEPUN, d$SITE, mean, na.rm = T)
 cor <- data.frame(cbind(MAT, MOR, MOR.L, PUN.L))
 cor$SITE <- row.names(cor)
 
 plt <- plot(jitter(cor$MOR.L,2)~jitter(cor$MAT,2), xlim = range(0:1), ylim = range(0:4), pch = 16,
             xlab = "Mean Food Security", ylab = "Mean Moralization Index of Local Deity",
             cex.axis = 1.2, cex.lab = 1.2)
 abline(lm(cor$MOR.L~cor$MAT))
 pos_vector <- rep(3, length(cor$SITE))
 pos_vector[cor$SITE %in% c("Inland Tanna")] <- 1
 pos_vector[cor$SITE %in% c("Tyva Republic")] <- 2
 text(MAT, MOR.L, labels=cor$SITE, cex= 1.2, pos = pos_vector)
 
 summary(lm(cor$MOR.L~cor$MAT))
 confint(lm(cor$MOR.L~cor$MAT))









