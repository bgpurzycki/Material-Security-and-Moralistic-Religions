################################################################################
# Analysis of Reproductive Outcomes
################################################################################
 library(rethinking)
  setwd("your path here")
 
######################################################################### Part 1
# First, lets simulate some data to check our statistical model
###################### Set seed for replication of results
set.seed(1)

###################### Make sites
Site <- rmultinom(300, prob=c(1,2,2,1,3,1,2,1),size=1) # Imbalanced site representation
Site <- which(Site==1,arr.ind=T)[,1]
hist(Site)

###################### Make wealth
Wealth <- rbinom(300, 0.3, size=1)                     # 0.3 are insecure
hist(Wealth)

###################### Make age
Age <- rpois(300,40)                                   # Adults
hist(Age)

###################### Make education
Education <- rpois(300, 5)                             # Basic education dist
hist(Education)

###################### Make male
Male <- rbinom(300, 0.5, size=1)                       # 0.5 are women
hist(Male)

################################################### Now make simulated outcomes
A1<-rnorm(8, 0,0.1)  # Var over group
A2<-rnorm(8, 0,0.1)  #
A3<-rnorm(8, 0,0.1)  #
A4<-rnorm(8, 0,0.2)  #
A5<-rnorm(8, 0,0.3)  #


X<-c() # Outcomes

#### Mu in model are the numeric effects below
Mu <- c(-2,0.9,0.2,0.05,-0.6)

for(i in 1:300){
X[i] <- rpois(1,exp((Mu[1]+A1[Site[i]]) + (Mu[2]+A2[Site[i]])*log(Age[i]) + (Mu[3]+A3[Site[i]])*Male[i] + (Mu[4]+A4[Site[i]])*Education[i] + (Mu[5]+A5[Site[i]])*Wealth[i] ) )
 }

hist(X)
RS<-X

#################################################### Extra data bits for indices
N <- 300            # Cases
P <- 5              # Params
L <- 8              # Sites

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  RS=RS,
  Age=Age,    
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site   
)

#################################################################### Stan Models
################################################### M1 is full model
model_code_M1="
data{
  int N;
  int P;
  int L;
  
  int<lower=0> RS[N];
  int Site[N];
  
  vector[N] Age;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}   

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;
  
  vector[P] Beta_raw[L];   # This is a little optimization trick
}

transformed parameters{
  vector[P] Beta[L];       # Convert to the true parameters

  for(l in 1:L){
   Beta[l]      = Mu; # + diag_pre_multiply(Sigma, Rho)*Beta_raw[l]; # Sigma=0
               }
} 

model{
vector[N] A;
vector[N] B;

############################################################### Top-level Priors 
  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);
  
 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);  # Priors on random effects
             }

  for(i in 1:N){               # Link functions
    B[i] = InvScale;
    A[i] = exp(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Education[i] + Beta[Site[i],5]*Wealth[i])*B[i];  
    }

  RS ~ neg_binomial(A,B);         
}
"

############################################################# M2 drops education
model_code_M2="
data{
  int N;
  int P;
  int L;

  int<lower=0> RS[N];
  int Site[N];

  vector[N] Age;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu; # + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;
vector[N] B;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

  for(i in 1:N){
    B[i] = InvScale;
    A[i] = exp(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],5]*Wealth[i])*B[i];  # M2 - Wealth Insecurity Only
    }

  RS ~ neg_binomial(A,B);
}
"

##################################################### M3 drops wealth insecurity
model_code_M3="
data{
  int N;
  int P;
  int L;

  int<lower=0> RS[N];
  int Site[N];

  vector[N] Age;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  real<lower=0> InvScale;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu; # + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;
vector[N] B;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);
  InvScale ~ cauchy(0,2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

  for(i in 1:N){
    B[i] = InvScale;
    A[i] = exp(Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Education[i])*B[i];  # M3 - Education Only
    }

  RS ~ neg_binomial(A,B);
}
"

####################################################################### Check M1
fit <- stan(model_code=model_code_M1, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=1234, control=list(metric=("diag_e")))

################################################# Check fit and MCMC performance
print(fit,pars=c("Mu","Sigma"))

Mu_pred <- get_posterior_mean(fit,"Mu")

windows()
plot(Mu, Mu_pred[,dim(Mu_pred)[2]])

Beta_pred <- get_posterior_mean(fit,"Beta")
Beta <- c(Mu+c(A1[1]+A2[1]+A3[1]+A4[1]+A5[1]),Mu+c(A1[2]+A2[2]+A3[2]+A4[2]+A5[2]),Mu+c(A1[3]+A2[3]+A3[3]+A4[3]+A5[3]),Mu+c(A1[4]+A2[4]+A3[4]+A4[4]+A5[4]),
          Mu+c(A1[5]+A2[5]+A3[5]+A4[5]+A5[5]),Mu+c(A1[6]+A2[6]+A3[6]+A4[6]+A5[6]),Mu+c(A1[7]+A2[7]+A3[7]+A4[7]+A5[7]),Mu+c(A1[8]+A2[8]+A3[8]+A4[8]+A5[8])) 

windows()
plot(Beta, Beta_pred[,dim(Beta_pred)[2]],ylim=c(-4,1))
cor(Beta, Beta_pred[,dim(Beta_pred)[2]])

windows()
traceplot(fit,pars=c("Mu","Sigma"))


######################################################################### Part 2
########################################################## Analysis of real data
d<-read.csv("OutcomeData.csv")
library(LaplacesDemon)

d2<-data.frame(d$SITE,d$CHILDREN,d$AGE,d$SEX,d$FORMALED,d$SEC1)  # Get variables
d3<-d2[complete.cases(d2),]                                      # Drop missings

Site <- as.numeric(d3$d.SITE)
RS <- d3$d.CHILDREN
Age <- ifelse( (d3$d.AGE - 15) >=45,45,d3$d.AGE - 15)            # Turn age into years of exposure to reproduction... i.e. cut off pre- and post- reproductive windows
Male <- d3$d.SEX
Education <- d3$d.FORMALED 
Wealth <- d3$d.SEC1         # Food SECURITY

N <- length(RS)     # Cases
P <- 5              # Params
L <- 8              # Sites

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  RS=RS,
  Age=Age,    
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site   
)


############################################################################# M1
fit_M1 <- stan(model_code=model_code_M1, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345, control=list(metric=("diag_e")))

# Check M1
print(fit_M1,pars="Mu")
print(fit_M1,pars="Beta")

windows()
traceplot(fit_M1,pars="Mu")
windows()
traceplot(fit_M1,pars="Beta")

BETA<-extract(fit_M1,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,2:5]
colnames(XX)<-c("Age","Male","Education","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################################# M2
fit_M2 <- stan(model_code=model_code_M2, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345, control=list(metric=("diag_e")))

# Check M2
print(fit_M2,pars="Mu")
print(fit_M2,pars="Beta")

windows()
traceplot(fit_M2,pars="Mu")
windows()
traceplot(fit_M2,pars="Beta")

BETA<-extract(fit_M2,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,5)]
colnames(XX)<-c("Age","Male","Food Security")
windows()
caterpillar.plot(XX)
}


############################################################################# M3
fit_M3 <- stan(model_code=model_code_M3, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=123456, control=list(metric=("diag_e")))

# Check M3
print(fit_M3,pars="Mu")
print(fit_M3,pars="Beta")

windows()
traceplot(fit_M3,pars="Mu")
windows()
traceplot(fit_M3,pars="Beta")

BETA<-extract(fit_M3,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,2:4]
colnames(XX)<-c("Age","Male","Education")
windows()
caterpillar.plot(XX)
}


############################################################# Make Results Table
 library(rethinking)
 library(xtable)

colPCIl <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[1]
                               }
                               K
                               }
colPCIh <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[2]
                               }
                               K
                               }

  Mu_M1<-extract(fit_M1,pars=c("Mu"))$Mu
  Mu_M2<-extract(fit_M2,pars=c("Mu"))$Mu
  Mu_M3<-extract(fit_M3,pars=c("Mu"))$Mu

  Res<-ResM<-ResL<-ResH<-matrix(NA,nrow=5,ncol=3)

  ResM[,1] <- round(colMeans(Mu_M1),2)
  ResM[,2] <- round(colMeans(Mu_M2),2)
  ResM[,3] <- round(colMeans(Mu_M3),2)

  ResL[,1] <- round(colPCIl(Mu_M1),2)
  ResL[,2] <- round(colPCIl(Mu_M2),2)
  ResL[,3] <- round(colPCIl(Mu_M3),2)

  ResH[,1] <- round(colPCIh(Mu_M1),2)
  ResH[,2] <- round(colPCIh(Mu_M2),2)
  ResH[,3] <- round(colPCIh(Mu_M3),2)


   ResL[4,2]<-ResL[5,3]<-ResH[4,2]<-ResH[5,3]<-ResM[4,2]<-ResM[5,3]<-NA

  for(i in 1:5){
  for(j in 1:3){
  Res[i,j] <- paste0(ResM[i,j]," (",ResL[i,j],", ",ResH[i,j],")")
             }}

  Res[4,2]<-Res[5,3]<-NA


  colnames(Res) <- c("M1","M2","M3")
  rownames(Res) <- c("Intercept","Age (Elasticity)","Male","Education","Food Security")

  xtable(Res)








