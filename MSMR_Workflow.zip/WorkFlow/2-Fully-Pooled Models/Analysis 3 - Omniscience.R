################################################################################
# Analysis of Belief in Omniscient Gods
################################################################################
 library(rethinking)
  setwd("your path here")

#################################################################### Stan Models
model_code_M1="
data{
  int N;
  int P;
  int L;
  int K;

  int<lower=0,upper=3> OmniBG[N];
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  ordered[K-1] c;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu;# + diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M1 - Wealth Insecurity and Education and Kids
  for(i in 1:N){
    A[i] = Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Kids[i] + Beta[Site[i],5]*Education[i] + Beta[Site[i],6]*Wealth[i];
      }

 for (i in 1:N){
   OmniBG[i] ~ ordered_logistic(A[i], c);
               }

}
"

model_code_M2="
data{
  int N;
  int P;
  int L;
  int K;

  int<lower=0,upper=3> OmniBG[N];
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  ordered[K-1] c;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu ;#+ diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M2 - Wealth Insecurity and Kids
  for(i in 1:N){
    A[i] = Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],4]*Kids[i] + Beta[Site[i],6]*Wealth[i];
      }

 for (i in 1:N){
   OmniBG[i] ~ ordered_logistic(A[i], c);
               }

}
"

model_code_M3="
data{
  int N;
  int P;
  int L;
  int K;

  int<lower=0,upper=3> OmniBG[N];
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  ordered[K-1] c;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu ;#+ diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M3 - Education and Wealth
  for(i in 1:N){
    A[i] = Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],5]*Education[i] + Beta[Site[i],6]*Wealth[i];
      }

 for (i in 1:N){
   OmniBG[i] ~ ordered_logistic(A[i], c);
               }

}
"

model_code_M4="
data{
  int N;
  int P;
  int L;
  int K;

  int<lower=0,upper=3> OmniBG[N];
  int Site[N];

  vector[N] Age;
  vector[N] Kids;
  vector[N] Wealth;
  vector[N] Education;
  vector[N] Male;
  vector[N] Omni;
}

parameters{
  vector[P] Mu;
  vector<lower=0>[P] Sigma;
  cholesky_factor_corr[P] Rho;
  ordered[K-1] c;

  vector[P] Beta_raw[L];
}

transformed parameters{
  vector[P] Beta[L];

  for(l in 1:L){
   Beta[l]      = Mu ;#+ diag_pre_multiply(Sigma, Rho)*Beta_raw[l];
               }
}

model{
vector[N] A;

  Mu ~ normal(0,5);
  Sigma ~ cauchy(0,2.5);
  Rho ~ lkj_corr_cholesky(2.5);

 for(l in 1:L){
  Beta_raw[l] ~ normal(0, 1);
             }

#### M4 - Omni Big and Wealth
  for(i in 1:N){
    A[i] = Beta[Site[i],1] + Beta[Site[i],2]*log(Age[i]) + Beta[Site[i],3]*Male[i] + Beta[Site[i],6]*Wealth[i] + Beta[Site[i],7]*Omni[i];
      }

 for (i in 1:N){
   OmniBG[i] ~ ordered_logistic(A[i], c);
               }

}
"

######################################################################### Part 2
########################################################## Analysis of real data
d<-read.csv("OutcomeData.csv")
library(LaplacesDemon)

d2<-data.frame(d$SITE,d$CHILDREN,d$AGE,d$SEX,d$FORMALED,d$SEC1,d$OMNI.BG)  # Get variables
d3<-d2[complete.cases(d2),]      # Drop missings

Site <- as.numeric(d3$d.SITE)
Kids <- d3$d.CHILDREN
Age <- ifelse( (d3$d.AGE - 15) >=45,45,d3$d.AGE - 15)     # Turn age into years of exposure to reproduction... ie cut off pre- and post- reproductive windows
Male <- d3$d.SEX
Education <- d3$d.FORMALED
Wealth <- d3$d.SEC1                                       # Food SECURITY
OmniBG <- (2*d3$d.OMNI.BG  +1)

N <- length(OmniBG)     # Cases
P <- 6              # Params
L <- 8              # Sites
K <- 3

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  K=K,
  OmniBG=OmniBG,
  Kids=Kids,
  Age=Age,
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site
)


############################################################################# M1
fit_M1 <- stan(model_code=model_code_M1, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345)

# Check M1
print(fit_M1,pars="Mu")
print(fit_M1,pars="Beta")

windows()
traceplot(fit_M1,pars="Mu")
windows()
traceplot(fit_M1,pars="Beta")

BETA<-extract(fit_M1,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,2:6]
colnames(XX)<-c("Age","Male","Kids","Education","Wealth")
windows()
caterpillar.plot(XX)
}


############################################################################# M2
fit_M2 <- stan(model_code=model_code_M2, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345)

# Check M2
print(fit_M2,pars="Mu")
print(fit_M2,pars="Beta")

windows()
traceplot(fit_M2,pars="Mu")
windows()
traceplot(fit_M2,pars="Beta")

BETA<-extract(fit_M2,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,4,6)]
colnames(XX)<-c("Age","Male","Kids","Wealth")
windows()
caterpillar.plot(XX)
}


############################################################################# M3
fit_M3 <- stan(model_code=model_code_M3, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345)

# Check M3
print(fit_M3,pars="Mu")
print(fit_M3,pars="Beta")

windows()
traceplot(fit_M3,pars="Mu")
windows()
traceplot(fit_M3,pars="Beta")

BETA<-extract(fit_M3,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,5,6)]
colnames(XX)<-c("Age","Male","Education","Wealth")
windows()
caterpillar.plot(XX)
}


############################################################# Make Results Table
 library(rethinking)
 library(xtable)

colPCIl <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[1]
                               }
                               K
                               }
colPCIh <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[2]
                               }
                               K
                               }

  Mu_M1<-extract(fit_M1,pars=c("Mu"))$Mu
  Mu_M2<-extract(fit_M2,pars=c("Mu"))$Mu
  Mu_M3<-extract(fit_M3,pars=c("Mu"))$Mu

  Res<-ResM<-ResL<-ResH<-matrix(NA,nrow=6,ncol=3)

  ResM[,1] <- round(colMeans(Mu_M1),2)
  ResM[,2] <- round(colMeans(Mu_M2),2)
  ResM[,3] <- round(colMeans(Mu_M3),2)

  ResL[,1] <- round(colPCIl(Mu_M1),2)
  ResL[,2] <- round(colPCIl(Mu_M2),2)
  ResL[,3] <- round(colPCIl(Mu_M3),2)

  ResH[,1] <- round(colPCIh(Mu_M1),2)
  ResH[,2] <- round(colPCIh(Mu_M2),2)
  ResH[,3] <- round(colPCIh(Mu_M3),2)


   ResL[5,2]<-ResL[4,3]<-ResH[5,2]<-ResH[4,3]<-ResM[5,2]<-ResM[4,3]<-NA

  for(i in 1:6){
  for(j in 1:3){
  Res[i,j] <- paste0(ResM[i,j]," (",ResL[i,j],", ",ResH[i,j],")")
             }}

  Res[5,2]<-Res[4,3]<-NA


  colnames(Res) <- c("M1","M2","M3")
  rownames(Res) <- c("Intercept","Age (Elasticity)","Male","Kids","Education","Food Security")

  xtable(Res)

 ResBig<-Res


######################################################################### Part 3
########################################################## Analysis of real data
d<-read.csv("Outcomes.csv")
library(LaplacesDemon)

d2<-data.frame(d$SITE,d$CHILDREN,d$AGE,d$SEX,d$FORMALED,d$SEC1,d$OMNI.LG,d$OMNI.BG)  # Get variables
d3<-d2[complete.cases(d2),]      # Drop missings

Site <- as.numeric(d3$d.SITE)
Kids <- d3$d.CHILDREN
Age <- ifelse( (d3$d.AGE - 15) >=45,45,d3$d.AGE - 15)    # Turn age into years of exposure to reproduction... ie cut off pre- and post- reproductive windows
Male <- d3$d.SEX
Education <- d3$d.FORMALED
Wealth <- d3$d.SEC1         # Food SECURITY
OmniBG <- (2*d3$d.OMNI.LG  +1)   # Hacky recode,   lets us use same models
Omni <- (2*d3$d.OMNI.BG)

N <- length(OmniBG)     # Cases
P <- 6              # Params
L <- 8              # Sites
K <- 3

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  K=K,
  OmniBG=OmniBG,
  Omni=Omni,
  Kids=Kids,
  Age=Age,
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site
)


############################################################################# M1
fit_M1 <- stan(model_code=model_code_M1, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345)

# Check M1
print(fit_M1,pars="Mu")
print(fit_M1,pars="Beta")

windows()
traceplot(fit_M1,pars="Mu")
windows()
traceplot(fit_M1,pars="Beta")

BETA<-extract(fit_M1,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,2:6]
colnames(XX)<-c("Age","Male","Kids","Education","Wealth")
windows()
caterpillar.plot(XX)
}


############################################################################# M2
fit_M2 <- stan(model_code=model_code_M2, data = model_dat, thin=1, iter = 2000, warmup=1000, chains = 1, refresh=1, seed=12345)

# Check M2
print(fit_M2,pars="Mu")
print(fit_M2,pars="Beta")

windows()
traceplot(fit_M2,pars="Mu")
windows()
traceplot(fit_M2,pars="Beta")

BETA<-extract(fit_M2,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,4,6)]
colnames(XX)<-c("Age","Male","Kids","Wealth")
windows()
caterpillar.plot(XX)
}


############################################################################# M3
fit_M3 <- stan(model_code=model_code_M3, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M3
print(fit_M3,pars="Mu")
print(fit_M3,pars="Beta")

windows()
traceplot(fit_M3,pars="Mu")
windows()
traceplot(fit_M3,pars="Beta")

BETA<-extract(fit_M3,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,5,6)]
colnames(XX)<-c("Age","Male","Education","Wealth")
windows()
caterpillar.plot(XX)
}


##############################################################################
P <- 7              # Params
L <- 8              # Sites
K <- 3

########################################################## Compile data for Stan
model_dat<-list(
  N=N,
  P=P,
  L=L,
  K=K,
  OmniBG=OmniBG,
  Omni=Omni,
  Kids=Kids,
  Age=Age,
  Wealth=Wealth,
  Education=Education,
  Male=Male,
  Site=Site
)

############################################################################# M1
fit_M4 <- stan(model_code=model_code_M4, data = model_dat,thin=1, iter = 2000, warmup=1000,chains = 1, refresh=1,seed=12345)

# Check M4
print(fit_M4,pars="Mu")
print(fit_M4,pars="Beta")

windows()
traceplot(fit_M4,pars="Mu")
windows()
traceplot(fit_M4,pars="Beta")

BETA<-extract(fit_M4,pars=c("Beta"))$Beta

for(i in 1:L){
XX<-BETA[,i,c(2,3,6,7)]
colnames(XX)<-c("Age","Male","Wealth","Omni")
windows()
caterpillar.plot(XX)
}




############################################################# Make Results Table
 library(rethinking)
 library(xtable)

colPCIl <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[1]
                               }
                               K
                               }
colPCIh <- function(X){
              G<-dim(X)
              K<-rep(NA,G[2])
              for(i in 1:G[2]){
               K[i] <- PCI(X[,i],0.9)[2]
                               }
                               K
                               }

  Mu_M1<-extract(fit_M1,pars=c("Mu"))$Mu
  Mu_M2<-extract(fit_M2,pars=c("Mu"))$Mu
  Mu_M3<-extract(fit_M3,pars=c("Mu"))$Mu
  Mu_M4<-extract(fit_M4,pars=c("Mu"))$Mu

  Res<-ResM<-ResL<-ResH<-matrix(NA,nrow=7,ncol=4)

  ResM[,1] <- c(round(colMeans(Mu_M1),2),NA)
  ResM[,2] <- c(round(colMeans(Mu_M2),2),NA)
  ResM[,3] <- c(round(colMeans(Mu_M3),2),NA)
  ResM[,4] <- round(colMeans(Mu_M4),2)

  ResL[,1] <- c(round(colPCIl(Mu_M1),2),NA)
  ResL[,2] <- c(round(colPCIl(Mu_M2),2),NA)
  ResL[,3] <- c(round(colPCIl(Mu_M3),2),NA)
  ResL[,4] <- round(colPCIl(Mu_M4),2)

  ResH[,1] <- c(round(colPCIh(Mu_M1),2),NA)
  ResH[,2] <- c(round(colPCIh(Mu_M2),2),NA)
  ResH[,3] <- c(round(colPCIh(Mu_M3),2),NA)
  ResH[,4] <- round(colPCIh(Mu_M4),2)


  ResL[5,2]<-ResL[4,3]<-ResH[5,2]<-ResH[4,3]<-ResM[5,2]<-ResM[4,3]<-NA
  ResL[4,4] <- ResL[5,4]<- ResH[4,4] <- ResH[5,4]<- ResM[4,4] <- ResM[5,4]<- NA

  for(i in 1:7){
  for(j in 1:4){
  Res[i,j] <- paste0(ResM[i,j]," (",ResL[i,j],", ",ResH[i,j],")")
             }}

  Res[5,4]<-Res[4,4]<-Res[5,2]<-Res[4,3]<-NA


  colnames(Res) <- c("M1","M2","M3","M4")
  rownames(Res) <- c("Intercept.","Age (Elasticity).","Male.","Kids.","Education.","Food Security.","OBG.")

  xtable(Res)

 ResLocal<-Res


################################################################## Merge Results

 ResFinal <- cbind(c(rep("Moralistic Diety",6),rep("Local Diety",7) ) ,   rbind(cbind(ResBig,rep(NA,6)), ResLocal))
colnames(ResFinal)<-c("Outcome","M1","M2","M3","M4")
 xtable(ResFinal)





